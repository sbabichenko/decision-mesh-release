# Minimal nested geometric empirical-Bayes experiment

## Specification

The frozen geometry-patch Decision Mesh fit was augmented with two nested
graph-distance covers using 6 and 12 farthest-point centers.

- Coarse parent basis: centered memberships from the two 6-center covers.
- Medium parent detail: 12-center memberships projected off the coarse space.
- Crossed detail: products of the two medium-detail cover bases, projected off
  both parent spaces.
- Feature coordinates were weighted-orthogonalized and nearly unsupported
  directions removed before fitting.
- The feature basis used covariates and baseline-model information from the
  complete design; coefficients and EB hyperparameters used training outcomes
  only.

Two variants used exactly the same features:

1. **Pooled:** one EB variance for all parent-cover coefficients and one for
   crossed interactions.
2. **Separate:** distinct EB variances for coarse parents, medium parent
   details, and crossed interactions.

## Main result

Relative to the existing single-scale crossed-cover implementation, the pooled
nested-basis model changed mean held-out NLL by:

- Overall: -0.00081842
- Low-WALA ramp: -0.00171027
- Middle-aged band: -0.00094115
- Seasoned: +0.00002141

It improved overall, ramp, and middle-aged NLL in 12/12 matched splits.

## Does separate multiscale shrinkage help?

Holding the feature space fixed, separate coarse and medium EB variances changed
NLL relative to pooled parent shrinkage by:

- Overall: +0.00003588
  (2/12 improved)
- Middle-aged band: +0.00008559
  (3/12 improved)
- Seasoned: -0.00005845
  (9/12 improved)

Positive is worse. Separate scale-specific EB variances therefore do not improve
this sample.

## Preferred minimal model

Use the nested and orthogonalized geometric feature construction, but retain
only two variance components:

- one shared parent-cover variance;
- one crossed-interaction variance.

Within that model:

- medium parent details beyond the coarse cover changed overall NLL by
  -0.00058724 on average;
- crossed interactions changed overall NLL by
  -0.00087960 on average.

Both increments improved all 12 splits.

## Interpretation

The experiment supports a multiscale geometric *representation*, but not a
multiscale EB variance law. The gain comes from separating coarse structure,
medium residual structure, and crossed residual structure into stable,
identifiable feature spaces. Adding another shrinkage hyperparameter for
coarse versus medium parent effects is unnecessary and slightly harmful.
