# Interaction-precision control test

## Design

For each of 12 frozen outer-split Decision Mesh topologies:

1. The preferred nested 6/12-center geometric basis was reconstructed.
2. A locally balanced four-way split was made using only pools in the outer
   training half.
3. One fold was used for inner validation.
4. Parent and interaction EB scales were estimated on the remaining inner
   training pools.
5. Interaction-precision multipliers 1, 1/2, and 1/4 were refit and compared on
   inner validation.
6. The selected multiplier was then applied after re-estimating the base EB
   scales on the complete outer training half.
7. Reporting used the untouched outer held-out pools.

The parent-cover precision was never changed. A multiplier of 1/4 doubles the
interaction prior standard deviation relative to the original EB value.

## Selection

The training-side selector chose:

multiplier
0.25    11
1.00     1

The quarter-precision rule improved inner-validation NLL relative to the
original precision in 11 of 12 splits, with mean change
-0.00009013.

## Outer held-out results

Quarter precision versus original EB precision:

- Overall mean NLL change: -0.00018845;
  improved 12/12.
- Middle-aged mean NLL change: -0.00023357;
  improved 10/12.
- Low-WALA ramp mean NLL change:
  -0.00029947.
- Seasoned mean NLL change:
  +0.00002961.

Training-selected rule versus original EB precision:

- Overall mean NLL change: -0.00017006;
  improved 11/12 with one unchanged split.
- Middle-aged mean NLL change: -0.00021699;
  improved 9/12.
- Low-WALA ramp mean NLL change:
  -0.00028586.
- Seasoned mean NLL change:
  +0.00002651.

Quarter precision also beat half precision overall in all 12 outer splits, with
mean additional improvement
-0.00007107.

## Interpretation

The original Gaussian EB interaction penalty is too strong for this feature
space. The tested optimum lies at the weakest-shrinkage boundary: quarter
precision was selected in 11/12 training-side validations and beat the original
precision on all 12 outer holdouts overall.

This is a nested control for the geometric correction layer conditional on the
frozen Decision Mesh topology and baseline fit. It is not a full nested
retraining of the adaptive mesh inside every inner fold.
