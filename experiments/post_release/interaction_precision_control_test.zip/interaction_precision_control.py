#!/usr/bin/env python3
from __future__ import annotations
import concurrent.futures as cf
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve

TWOSCALE_PATH = Path('/mnt/data/control_test_work/twoscale_geometry.py')
spec = importlib.util.spec_from_file_location('twoscale', TWOSCALE_PATH)
ts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ts)

DATA = Path('/mnt/data/control_test_work/release/DecisionMesh_local_split_release_2026-07-30/data/ginnie_design.csv')
LAW_PATH = Path('/mnt/data/control_test_work/release/DecisionMesh_local_split_release_2026-07-30/core/auditing/law_shared.json')
BASE = Path('/mnt/data/control_test_work/baselines')
OUT = Path('/mnt/data/interaction_precision_control')
OUT.mkdir(parents=True, exist_ok=True)
SEEDS = [101,102,103,104,105,106,107,109,110,111,112,114]
MULTIPLIERS = [1.0, 0.5, 0.25]
RAW = pd.read_csv(DATA)
LAW = json.load(open(LAW_PATH))['law']


def spatial_blocks(indices: np.ndarray, points: np.ndarray, max_size: int = 24):
    out = []
    stack = [np.asarray(indices, int)]
    while stack:
        idx = stack.pop()
        if len(idx) <= max_size:
            out.append(idx)
            continue
        pts = points[idx]
        spans = np.ptp(pts, axis=0)
        dim = int(np.argmax(spans))
        order = idx[np.argsort(points[idx, dim], kind='mergesort')]
        mid = len(order) // 2
        stack.append(order[mid:])
        stack.append(order[:mid])
    return out


def local_balanced_inner_fold(outer_train: np.ndarray, points: np.ndarray, exposure: np.ndarray,
                              seed: int, nfold: int = 4):
    """Assign only outer-training rows to spatially local exposure-balanced folds."""
    fold = np.full(len(outer_train), -1, int)
    rng = np.random.default_rng(seed * 7919 + 17)
    blocks = spatial_blocks(np.flatnonzero(outer_train), points, max_size=24)
    for block_id, block in enumerate(blocks):
        # Randomized tie breaking followed by descending exposure and greedy load balance.
        jitter = rng.random(len(block))
        order = np.lexsort((jitter, -exposure[block]))
        loads = np.zeros(nfold, float)
        counts = np.zeros(nfold, int)
        for loc in order:
            i = block[loc]
            min_load = loads.min()
            candidates = np.flatnonzero(np.isclose(loads, min_load, rtol=0, atol=1e-12))
            if len(candidates) > 1:
                min_count = counts[candidates].min()
                candidates = candidates[counts[candidates] == min_count]
            f = int(candidates[(block_id + seed + counts.sum()) % len(candidates)])
            fold[i] = f
            loads[f] += exposure[i]
            counts[f] += 1
    return fold


def posterior_value(x, beta, k, n, eta0, law, lam, xs, lw):
    ll = ts.marginal_stats(k, n, eta0 + x @ beta, law, xs, lw)[0].sum()
    return float(ll - 0.5 * np.dot(lam, beta * beta))


def fit_fixed_penalty(x, groups, k, n, eta0, law, tau, precision_multiplier,
                      start_beta=None, max_outer=18, tol=2e-6):
    xs, ws = np.polynomial.hermite_e.hermegauss(20)
    lw = np.log(ws / ws.sum())
    p = x.shape[1]
    beta = np.zeros(p) if start_beta is None else np.asarray(start_beta, float).copy()
    group_prec = 1.0 / np.maximum(np.asarray(tau, float), 1e-12) ** 2
    # Group 0 is pooled parent effects; group 1 is crossed interactions.
    if len(group_prec) > 1:
        group_prec[1] *= precision_multiplier
    lam = group_prec[groups]
    trace = []
    for outer in range(max_outer):
        corr = x @ beta
        _, score, second = ts.marginal_stats(k, n, eta0 + corr, law, xs, lw)
        w = np.clip(-second, 1e-4, 5e5)
        z = corr + score / w
        h = x.T @ (x * w[:, None])
        h.flat[::p+1] += lam
        rhs = x.T @ (w * z)
        try:
            cfact = cho_factor(h, lower=True, check_finite=False)
            proposal = cho_solve(cfact, rhs, check_finite=False)
        except Exception:
            proposal = np.linalg.solve(h, rhs)
        old = posterior_value(x, beta, k, n, eta0, law, lam, xs, lw)
        step = 1.0
        value = -np.inf
        while step >= 1/256:
            trial = beta + step * (proposal - beta)
            value = posterior_value(x, trial, k, n, eta0, law, lam, xs, lw)
            if value >= old - 1e-7:
                break
            step *= 0.5
        delta = float(np.max(np.abs(trial-beta))) if len(beta) else 0.0
        beta = trial
        trace.append({'outer':outer,'post':value,'step':step,'max_delta':delta})
        if delta < tol:
            break
    return beta, group_prec, trace


def build_design(seed: int, obs: pd.DataFrame, mesh_path: Path):
    points = np.column_stack([
        RAW.wala.to_numpy(float) / 360.0,
        (RAW.wac.to_numpy(float) - 2.6) / 5.0,
    ])
    verts, graph = ts.load_mesh_graph(str(mesh_path))
    _, dist_a = ts.farthest_centers(graph, verts, 12, (0.0,0.0))
    _, dist_b = ts.farthest_centers(graph, verts, 12, (0.5,0.5))
    m6a = ts.soft_memberships(points, verts, dist_a[:6], 3, 1.0)
    m6b = ts.soft_memberships(points, verts, dist_b[:6], 3, 1.0)
    m12a = ts.soft_memberships(points, verts, dist_a, 3, 1.0)
    m12b = ts.soft_memberships(points, verts, dist_b, 3, 1.0)
    basis_mask = np.ones(len(obs), dtype=bool)
    basis_weights = np.maximum(obs['info'].to_numpy(float), 1e-5)
    x, groups, names, diagnostics = ts.build_two_scale_design(
        m6a,m6b,m12a,m12b,basis_mask,basis_weights,'pooled'
    )
    return x, groups, names, diagnostics, points


def evaluate_regions(k,n,eta,mask_outer):
    wala=RAW.wala.to_numpy(float); wac=RAW.wac.to_numpy(float)
    masks={
      'all':mask_outer,
      'ramp':mask_outer & (wala<24)&(wac>=5.5)&(wac<7),
      'mid':mask_outer & (wala>=60)&(wala<200),
      'seasoned':mask_outer & (wala>=200)&(wala<300)&(wac>=5.5)&(wac<7),
    }
    return {f'nll_{key}':ts.evaluate_nll(k,n,eta,m,LAW) for key,m in masks.items()}


def run_seed(seed: int):
    rd=BASE/f'seed_{seed}'
    obs_path=rd/'run_obs.csv'; mesh_path=rd/'run_mesh.csv'
    if not obs_path.exists() or not mesh_path.exists():
        raise FileNotFoundError(f'missing baseline seed {seed}')
    obs=pd.read_csv(obs_path).sort_values('pid').reset_index(drop=True)
    n=RAW.n0.to_numpy(float); k=RAW.k_term.to_numpy(float)
    ph=np.clip(obs.p_hat.to_numpy(float),1e-12,1-1e-12)
    eta0=np.log(ph/(1-ph))
    outer_train=obs.is_train.to_numpy(int)==1
    outer_held=~outer_train
    x,groups,names,diagnostics,points=build_design(seed,obs,mesh_path)
    fold=local_balanced_inner_fold(outer_train,points,n,seed,nfold=4)
    val_fold=seed % 4
    inner_val=outer_train & (fold==val_fold)
    inner_train=outer_train & ~inner_val
    if inner_val.sum()<1000 or inner_train.sum()<1000:
        raise RuntimeError('bad inner split')

    # Estimate the reference EB scales using only inner-training outcomes.
    beta_inner_eb,tau_inner,trace_inner=ts.fit_laplace_eb(
        x[inner_train],groups,k[inner_train],n[inner_train],eta0[inner_train],LAW,
        max_outer=10,verbose=False
    )
    inner_rows=[]
    for mult in MULTIPLIERS:
        beta,prec,trace=fit_fixed_penalty(
            x[inner_train],groups,k[inner_train],n[inner_train],eta0[inner_train],LAW,
            tau_inner,mult,start_beta=beta_inner_eb
        )
        eta=eta0+x@beta
        inner_nll=ts.evaluate_nll(k,n,eta,inner_val,LAW)
        inner_rows.append({'seed':seed,'multiplier':mult,'inner_validation_nll':inner_nll,
                           'inner_train_nll':ts.evaluate_nll(k,n,eta,inner_train,LAW),
                           'tau_parent_inner':float(tau_inner[0]),
                           'tau_interaction_inner':float(tau_inner[1]),
                           'iterations_inner':len(trace)})
    inner_df=pd.DataFrame(inner_rows).sort_values(['inner_validation_nll','multiplier'],ascending=[True,False])
    selected=float(inner_df.iloc[0].multiplier)

    # Re-estimate base EB scales on all outer-training pools, then apply selected multiplier.
    beta_full_eb,tau_full,trace_full_eb=ts.fit_laplace_eb(
        x[outer_train],groups,k[outer_train],n[outer_train],eta0[outer_train],LAW,
        max_outer=10,verbose=False
    )
    outer_rows=[]
    coefficient_rows=[]
    for mult in MULTIPLIERS:
        beta,prec,trace=fit_fixed_penalty(
            x[outer_train],groups,k[outer_train],n[outer_train],eta0[outer_train],LAW,
            tau_full,mult,start_beta=beta_full_eb
        )
        eta=eta0+x@beta
        metrics=evaluate_regions(k,n,eta,outer_held)
        outer_rows.append({'seed':seed,'multiplier':mult,'selected':int(mult==selected),
                           'tau_parent_full':float(tau_full[0]),
                           'tau_interaction_full':float(tau_full[1]),
                           'effective_tau_interaction':float(tau_full[1]/math.sqrt(mult)),
                           'parameters':len(beta),'iterations_full':len(trace),**metrics})
        if mult==selected:
            coefficient_rows=pd.DataFrame({'coefficient':np.arange(len(beta)),'group':groups,'name':names,'beta':beta})
            output_obs=obs.copy(); output_obs['p_hat_control']=1/(1+np.exp(-eta)); output_obs['control_correction']=x@beta
    seed_out=OUT/f'seed_{seed}'; seed_out.mkdir(exist_ok=True)
    inner_df.to_csv(seed_out/'inner_selection.csv',index=False)
    pd.DataFrame(outer_rows).to_csv(seed_out/'outer_evaluation.csv',index=False)
    coefficient_rows.to_csv(seed_out/'selected_coefficients.csv',index=False)
    output_obs.to_csv(seed_out/'selected_run_obs.csv',index=False)
    with open(seed_out/'metadata.json','w') as f:
        json.dump({'seed':seed,'selected_multiplier':selected,'inner_train_rows':int(inner_train.sum()),
                   'inner_validation_rows':int(inner_val.sum()),
                   'inner_train_exposure':float(n[inner_train].sum()),
                   'inner_validation_exposure':float(n[inner_val].sum()),
                   'outer_held_rows':int(outer_held.sum()),'diagnostics':diagnostics,
                   'tau_inner':tau_inner.tolist(),'tau_full':tau_full.tolist()},f,indent=2)
    selected_row=[r for r in outer_rows if r['selected']][0]
    return selected_row, inner_rows, outer_rows


def main():
    all_selected=[]; all_inner=[]; all_outer=[]
    workers=int(os.environ.get('CONTROL_WORKERS','3'))
    with cf.ProcessPoolExecutor(max_workers=workers) as ex:
        futs={ex.submit(run_seed,s):s for s in SEEDS}
        for fut in cf.as_completed(futs):
            seed=futs[fut]
            try:
                selected,inner,outer=fut.result()
                all_selected.append(selected);all_inner.extend(inner);all_outer.extend(outer)
                print('completed',seed,'selected',selected['multiplier'],'nll',selected['nll_all'],flush=True)
            except Exception as exc:
                print('ERROR',seed,type(exc).__name__,str(exc),flush=True)
    pd.DataFrame(all_inner).sort_values(['seed','multiplier']).to_csv(OUT/'inner_selection_all.csv',index=False)
    pd.DataFrame(all_outer).sort_values(['seed','multiplier']).to_csv(OUT/'outer_all_multipliers.csv',index=False)
    pd.DataFrame(all_selected).sort_values('seed').to_csv(OUT/'outer_selected_results.csv',index=False)

if __name__=='__main__': main()
