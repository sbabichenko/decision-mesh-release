#!/usr/bin/env python3
"""Minimal two-scale crossed geometric-cover empirical-Bayes correction.

The base mesh fit is frozen.  Two nested graph-distance cover constructions are
built at 6 and 12 centers.  The correction decomposes into

    coarse parents + medium parent detail + medium crossed detail,

where each finer block is residualized against all coarser blocks under the
training Fisher-information inner product.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve, null_space
from scipy.optimize import minimize
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree
from scipy.special import expit, gammaln, logsumexp


# ---------- mesh geometry ----------

def load_mesh_graph(mesh_csv: str):
    m = pd.read_csv(mesh_csv)
    key_to_idx: dict[tuple[float, float], int] = {}
    verts: list[tuple[float, float]] = []
    tris: list[list[int]] = []
    for row in m.itertuples(index=False):
        tri: list[int] = []
        for x, y in [(row.x0, row.y0), (row.x1, row.y1), (row.x2, row.y2)]:
            key = (round(float(x), 12), round(float(y), 12))
            if key not in key_to_idx:
                key_to_idx[key] = len(verts)
                verts.append((float(x), float(y)))
            tri.append(key_to_idx[key])
        tris.append(tri)
    verts_a = np.asarray(verts, float)
    tris_a = np.asarray(tris, int)
    edges: dict[tuple[int, int], float] = {}
    for a, b, c in tris_a:
        for u, v in [(a, b), (b, c), (c, a)]:
            if u > v:
                u, v = v, u
            dist = float(np.linalg.norm(verts_a[u] - verts_a[v]))
            edges[(u, v)] = min(edges.get((u, v), 1e300), dist)
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    for (u, v), w in edges.items():
        rows.extend([u, v])
        cols.extend([v, u])
        vals.extend([w, w])
    graph = csr_matrix((vals, (rows, cols)), shape=(len(verts_a), len(verts_a)))
    return verts_a, graph


def farthest_centers(graph, verts: np.ndarray, k: int, start_xy: tuple[float, float]):
    start = int(np.argmin(np.sum((verts - np.asarray(start_xy)) ** 2, axis=1)))
    centers = [start]
    min_dist = dijkstra(graph, directed=False, indices=start)
    for _ in range(1, k):
        finite = np.where(np.isfinite(min_dist), min_dist, -1)
        nxt = int(np.argmax(finite + 1e-12 * np.arange(len(finite))))
        if nxt in centers:
            break
        centers.append(nxt)
        dn = dijkstra(graph, directed=False, indices=nxt)
        min_dist = np.minimum(min_dist, dn)
    distances = dijkstra(graph, directed=False, indices=np.asarray(centers, int))
    return np.asarray(centers, int), np.asarray(distances, float)


def soft_memberships(points: np.ndarray, verts: np.ndarray, distances: np.ndarray,
                     topk: int = 3, bandwidth_mult: float = 1.0):
    nearest = cKDTree(verts).query(points, k=1)[1]
    dist = distances[:, nearest].T
    kk = min(topk, dist.shape[1])
    idx = np.argpartition(dist, kk - 1, axis=1)[:, :kk]
    selected = np.take_along_axis(dist, idx, axis=1)
    h = np.maximum(selected.max(axis=1) * bandwidth_mult, 1e-6)
    weights = np.exp(-0.5 * (selected / h[:, None]) ** 2)
    weights /= np.maximum(weights.sum(axis=1, keepdims=True), 1e-300)
    out = np.zeros_like(dist)
    np.put_along_axis(out, idx, weights, axis=1)
    return out


# ---------- weighted basis construction ----------

def centered_cover_basis(membership: np.ndarray, train: np.ndarray, weights: np.ndarray):
    mass = np.sum(membership[train] * weights[:, None], axis=0)
    mass /= mass.sum()
    rotation = null_space(mass.reshape(1, -1))
    return membership @ rotation


def weighted_orthonormalize(x: np.ndarray, train: np.ndarray, weights: np.ndarray,
                            relative_tol: float = 1e-5, absolute_tol: float = 1e-7):
    """Return a W-orthonormal basis for the column space observed in training.

    The normalization is weighted RMS one rather than weighted norm one.  SVD
    truncation removes directions that are nearly absent from the training
    sample but can otherwise explode on held-out rows after residualization.
    """
    if x.shape[1] == 0:
        return x, np.zeros(0, bool), np.zeros(0)
    sw = float(weights.sum())
    means = np.sum(x[train] * weights[:, None], axis=0) / sw
    centered = x - means
    sqrtw = np.sqrt(np.maximum(weights, 1e-12))
    weighted_train = centered[train] * sqrtw[:, None]
    _, singular, vt = np.linalg.svd(weighted_train, full_matrices=False)
    if singular.size == 0 or singular[0] <= 0:
        return np.zeros((len(x), 0)), np.zeros(x.shape[1], bool), singular
    threshold = max(relative_tol * singular[0], absolute_tol * np.sqrt(sw))
    keep_s = singular > threshold
    rotation = vt[keep_s].T
    basis = centered @ rotation
    basis *= (np.sqrt(sw) / singular[keep_s])[None, :]
    return basis, keep_s, singular

def weighted_residualize(x: np.ndarray, against: np.ndarray, train: np.ndarray,
                         weights: np.ndarray):
    """Residualize columns of x against columns of `against` in training W metric."""
    if x.shape[1] == 0 or against.shape[1] == 0:
        return x.copy()
    sqrtw = np.sqrt(np.maximum(weights, 1e-12))
    aw = against[train] * sqrtw[:, None]
    xw = x[train] * sqrtw[:, None]
    coef, *_ = np.linalg.lstsq(aw, xw, rcond=1e-10)
    return x - against @ coef


def build_two_scale_design(m6a: np.ndarray, m6b: np.ndarray,
                           m12a: np.ndarray, m12b: np.ndarray,
                           train: np.ndarray, weights: np.ndarray,
                           model: str):
    # Coarse parents, represented by a stable weighted-orthonormal basis.
    a6 = centered_cover_basis(m6a, train, weights)
    b6 = centered_cover_basis(m6b, train, weights)
    x0, _, s0 = weighted_orthonormalize(
        np.concatenate([a6, b6], axis=1), train, weights
    )

    # Medium parent detail: remove all structure representable by either coarse cover.
    a12 = centered_cover_basis(m12a, train, weights)
    b12 = centered_cover_basis(m12b, train, weights)
    a_resid = weighted_residualize(a12, x0, train, weights)
    b_resid = weighted_residualize(b12, x0, train, weights)
    a1, _, sa = weighted_orthonormalize(a_resid, train, weights)
    b1, _, sb = weighted_orthonormalize(b_resid, train, weights)
    medium_raw = np.concatenate([a1, b1], axis=1)
    x1, _, s1 = weighted_orthonormalize(medium_raw, train, weights)

    # Crossed medium detail, with all parent-cover directions removed.
    interaction_raw = np.einsum('ij,ik->ijk', a1, b1, optimize=True).reshape(len(a1), -1)
    parent_space = np.concatenate([x0, x1], axis=1)
    interaction_resid = weighted_residualize(interaction_raw, parent_space, train, weights)
    xi, _, si = weighted_orthonormalize(
        interaction_resid, train, weights, relative_tol=3e-4
    )

    if model == 'coarse':
        x = x0
        groups = np.zeros(x0.shape[1], int)
        names = np.array(['coarse'] * x0.shape[1], object)
    elif model == 'parents':
        x = np.concatenate([x0, x1], axis=1)
        groups = np.concatenate([
            np.zeros(x0.shape[1], int),
            np.ones(x1.shape[1], int),
        ])
        names = np.array(['coarse'] * x0.shape[1] + ['medium'] * x1.shape[1], object)
    elif model == 'parents_pooled':
        x = np.concatenate([x0, x1], axis=1)
        groups = np.zeros(x.shape[1], int)
        names = np.array(['coarse'] * x0.shape[1] + ['medium'] * x1.shape[1], object)
    elif model == 'pooled':
        x = np.concatenate([x0, x1, xi], axis=1)
        groups = np.concatenate([
            np.zeros(x0.shape[1] + x1.shape[1], int),
            np.ones(xi.shape[1], int),
        ])
        names = np.array(
            ['coarse'] * x0.shape[1]
            + ['medium'] * x1.shape[1]
            + ['interaction'] * xi.shape[1],
            object,
        )
    elif model == 'full':
        x = np.concatenate([x0, x1, xi], axis=1)
        groups = np.concatenate([
            np.zeros(x0.shape[1], int),
            np.ones(x1.shape[1], int),
            np.full(xi.shape[1], 2, int),
        ])
        names = np.array(
            ['coarse'] * x0.shape[1]
            + ['medium'] * x1.shape[1]
            + ['interaction'] * xi.shape[1],
            object,
        )
    else:
        raise ValueError(f'unknown model {model!r}')

    diagnostics = {
        'rank_coarse': int(x0.shape[1]),
        'rank_medium': int(x1.shape[1]),
        'rank_interaction': int(xi.shape[1]),
        'medium_raw_columns': int(medium_raw.shape[1]),
        'interaction_raw_columns': int(interaction_raw.shape[1]),
        'condition_coarse': float(s0[0] / s0[-1]) if len(s0) and s0[-1] > 0 else float('inf'),
        'condition_medium': float(s1[0] / s1[-1]) if len(s1) and s1[-1] > 0 else float('inf'),
        'condition_interaction_kept': float(si[0] / si[xi.shape[1]-1]) if xi.shape[1] and len(si) >= xi.shape[1] else float('inf'),
    }
    return x.astype(np.float64), groups, names, diagnostics


# ---------- heavy-tailed marginal likelihood ----------

def stratum_law(n: np.ndarray):
    return np.digitize(n, [128, 512, 4096])


def component_quadrature(k, n, eta, s2, xs, lw):
    uh = np.zeros_like(eta)
    for _ in range(35):
        p = expit(eta + uh)
        grad = n * p - k + uh / s2
        h = n * p * (1 - p) + 1 / s2
        step = np.clip(grad / h, -2, 2)
        new = np.clip(uh - step, -12, 12)
        if np.max(np.abs(new - uh)) < 1e-8:
            uh = new
            break
        uh = new
    p = expit(eta + uh)
    scale = 1 / np.sqrt(np.maximum(n * p * (1 - p) + 1 / s2, 1e-12))
    u = uh[None, :] + xs[:, None] * scale[None, :]
    q = expit(eta[None, :] + u)
    loglik = (
        k[None, :] * np.log(np.clip(q, 1e-14, 1))
        + (n - k)[None, :] * np.log1p(-np.clip(q, 0, 1 - 1e-14))
    )
    terms = lw[:, None] + 0.5 * xs[:, None] ** 2 + loglik - 0.5 * u * u / s2
    log_i = logsumexp(terms, axis=0) + np.log(scale) - 0.5 * np.log(s2)
    posterior_w = np.exp(terms - logsumexp(terms, axis=0)[None, :])
    score_node = k[None, :] - n[None, :] * q
    second_node = -n[None, :] * q * (1 - q)
    score = np.sum(posterior_w * score_node, axis=0)
    second = (
        np.sum(posterior_w * (second_node + score_node ** 2), axis=0)
        - score ** 2
    )
    return log_i, score, second


def marginal_stats(k, n, eta, law, xs, lw):
    log_l = np.empty_like(eta)
    score = np.empty_like(eta)
    second = np.empty_like(eta)
    strata = stratum_law(n)
    for s in range(4):
        mask = strata == s
        if not np.any(mask):
            continue
        pi, s0, s_large, _ = law[s]
        ll, sl, hl = component_quadrature(k[mask], n[mask], eta[mask], s_large, xs, lw)
        l0, s_small, h0 = component_quadrature(k[mask], n[mask], eta[mask], s0, xs, lw)
        aa = np.log(pi) + ll
        bb = np.log(1 - pi) + l0
        den = logsumexp(np.vstack([aa, bb]), axis=0)
        wa = np.exp(aa - den)
        wb = 1 - wa
        sc = wa * sl + wb * s_small
        sec = wa * (hl + sl * sl) + wb * (h0 + s_small * s_small) - sc * sc
        log_l[mask] = den
        score[mask] = sc
        second[mask] = sec
    return log_l, score, second


def fit_laplace_eb(x, groups, k, n, eta0, law, max_outer=8, verbose=False):
    xs, ws = np.polynomial.hermite_e.hermegauss(20)
    lw = np.log(ws / ws.sum())
    p = x.shape[1]
    unique = np.unique(groups)
    ng = len(unique)
    beta = np.zeros(p)
    log_tau = np.full(ng, -2.0)
    trace = []

    for outer in range(max_outer):
        corr = x @ beta
        eta = eta0 + corr
        _, score, second = marginal_stats(k, n, eta, law, xs, lw)
        fisher_w = np.clip(-second, 1e-4, 5e5)
        z = corr + score / fisher_w
        xw = x * fisher_w[:, None]
        hessian = x.T @ xw
        rhs = x.T @ (fisher_w * z)
        counts = np.array([(groups == g).sum() for g in unique], float)

        def evidence_objective(lt, return_beta=False):
            tau = np.exp(lt)
            lambda_group = 1 / (tau * tau)
            lam = lambda_group[groups]
            matrix = hessian.copy()
            matrix.flat[::p + 1] += lam
            try:
                cf = cho_factor(matrix, lower=True, check_finite=False)
                solution = cho_solve(cf, rhs, check_finite=False)
                logdet_matrix = 2 * np.log(np.diag(cf[0])).sum()
            except Exception:
                return (1e100, None) if return_beta else 1e100
            logdet_lambda = np.sum(counts * np.log(lambda_group))
            evidence = 0.5 * np.dot(rhs, solution) + 0.5 * logdet_lambda - 0.5 * logdet_matrix
            return (-evidence, solution) if return_beta else -evidence

        opt = minimize(
            evidence_objective,
            log_tau,
            method='L-BFGS-B',
            bounds=[(-12.0, 2.0)] * ng,
            options={'maxiter': 80, 'ftol': 1e-10},
        )
        log_tau = opt.x
        _, new_beta = evidence_objective(log_tau, True)
        lam = 1 / (np.exp(log_tau[groups]) ** 2)

        def posterior(b):
            ll = marginal_stats(k, n, eta0 + x @ b, law, xs, lw)[0].sum()
            return ll - 0.5 * np.dot(lam, b * b)

        old_post = posterior(beta)
        step = 1.0
        while step > 1 / 128:
            trial = beta + step * (new_beta - beta)
            value = posterior(trial)
            if value >= old_post - 1e-7:
                break
            step *= 0.5
        max_delta = float(np.max(np.abs(trial - beta)))
        beta = trial
        record = {
            'outer': outer,
            'post': float(value),
            'step': float(step),
            'max_delta': max_delta,
            'tau': np.exp(log_tau).tolist(),
            'mean_W': float(fisher_w.mean()),
            'min_W': float(fisher_w.min()),
            'evidence_success': bool(opt.success),
        }
        trace.append(record)
        if verbose:
            print('[fit]', record, flush=True)
        if max_delta < 2e-4:
            break
    return beta, np.exp(log_tau), trace


def evaluate_nll(k, n, eta, mask, law):
    xs, ws = np.polynomial.hermite_e.hermegauss(20)
    lw = np.log(ws / ws.sum())
    log_l = marginal_stats(k[mask], n[mask], eta[mask], law, xs, lw)[0]
    const = gammaln(n[mask] + 1) - gammaln(k[mask] + 1) - gammaln(n[mask] - k[mask] + 1)
    return float(np.mean(-(log_l + const)))


# ---------- experiment driver ----------

def run(args):
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(args.data)
    obs = pd.read_csv(args.obs).sort_values('pid').reset_index(drop=True)
    n = raw.n0.to_numpy(float)
    k = raw.k_term.to_numpy(float)
    probability = np.clip(obs.p_hat.to_numpy(float), 1e-12, 1 - 1e-12)
    eta0 = np.log(probability / (1 - probability))
    train = obs.is_train.to_numpy(int) == 1
    held = ~train
    points = np.column_stack([
        raw.wala.to_numpy(float) / 360.0,
        (raw.wac.to_numpy(float) - 2.6) / 5.0,
    ])
    verts, graph = load_mesh_graph(args.mesh)
    start_a = tuple(float(x) for x in args.start_a.split(','))
    start_b = tuple(float(x) for x in args.start_b.split(','))
    centers_a, dist_a = farthest_centers(graph, verts, args.medium_centers, start_a)
    centers_b, dist_b = farthest_centers(graph, verts, args.medium_centers, start_b)

    # The farthest-point order is nested; first coarse_centers are the coarse cover.
    coarse = args.coarse_centers
    m6a = soft_memberships(points, verts, dist_a[:coarse], args.topk, args.bandwidth)
    m6b = soft_memberships(points, verts, dist_b[:coarse], args.topk, args.bandwidth)
    m12a = soft_memberships(points, verts, dist_a, args.topk, args.bandwidth)
    m12b = soft_memberships(points, verts, dist_b, args.topk, args.bandwidth)

    # The feature coordinate system is defined from covariates and baseline information
    # over the full design, while coefficients and EB scales are fit on training outcomes only.
    # This avoids nearly-unseen geometric directions exploding on held-out pools.
    basis_mask = np.ones(len(obs), dtype=bool)
    basis_weights = np.maximum(obs['info'].to_numpy(float), 1e-5)
    law = json.load(open(args.law))['law']
    masks = {
        'all': held,
        'ramp': held & (raw.wala.to_numpy() < 24) & (raw.wac.to_numpy() >= 5.5) & (raw.wac.to_numpy() < 7),
        'mid': held & (raw.wala.to_numpy() >= 60) & (raw.wala.to_numpy() < 200),
        'seasoned': held & (raw.wala.to_numpy() >= 200) & (raw.wala.to_numpy() < 300) & (raw.wac.to_numpy() >= 5.5) & (raw.wac.to_numpy() < 7),
    }

    rows = []
    for model in [m.strip() for m in args.models.split(',') if m.strip()]:
        x, groups, names, diagnostics = build_two_scale_design(
            m6a, m6b, m12a, m12b, basis_mask, basis_weights, model
        )
        beta, tau, trace = fit_laplace_eb(
            x[train], groups, k[train], n[train], eta0[train], law,
            max_outer=args.outer, verbose=args.verbose,
        )
        correction = x @ beta
        eta = eta0 + correction
        metrics = {f'nll_{name}': evaluate_nll(k, n, eta, mask, law) for name, mask in masks.items()}
        row = {
            'model': model,
            'coarse_centers': coarse,
            'medium_centers': args.medium_centers,
            'topk': args.topk,
            'bandwidth': args.bandwidth,
            'parameters': int(len(beta)),
            'train_nll': evaluate_nll(k, n, eta, train, law),
            'taus': ';'.join(f'{value:.10g}' for value in tau),
            'correction_rms': float(np.sqrt(np.mean(correction[held] ** 2))),
            'correction_max': float(np.max(np.abs(correction[held]))),
            **diagnostics,
            **metrics,
        }
        rows.append(row)
        model_dir = output / model
        model_dir.mkdir(exist_ok=True)
        output_obs = obs.copy()
        output_obs['p_hat'] = expit(eta)
        output_obs['multiscale_correction'] = correction
        output_obs.to_csv(model_dir / 'run_obs.csv', index=False)
        pd.DataFrame({
            'coefficient': np.arange(len(beta)),
            'group': groups,
            'name': names,
            'beta': beta,
        }).to_csv(model_dir / 'coefficients.csv', index=False)
        with open(model_dir / 'fit.json', 'w') as handle:
            json.dump({
                'tau': tau.tolist(),
                'trace': trace,
                'centersA': centers_a.tolist(),
                'centersB': centers_b.tolist(),
                'diagnostics': diagnostics,
            }, handle, indent=2)
        print('[result]', row, flush=True)
    pd.DataFrame(rows).to_csv(output / 'metrics.csv', index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--obs', required=True)
    parser.add_argument('--mesh', required=True)
    parser.add_argument('--data', required=True)
    parser.add_argument('--law', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--coarse-centers', type=int, default=6)
    parser.add_argument('--medium-centers', type=int, default=12)
    parser.add_argument('--topk', type=int, default=3)
    parser.add_argument('--bandwidth', type=float, default=1.0)
    parser.add_argument('--start-a', default='0,0')
    parser.add_argument('--start-b', default='0.5,0.5')
    parser.add_argument('--models', default='coarse,parents,full')
    parser.add_argument('--outer', type=int, default=8)
    parser.add_argument('--verbose', action='store_true')
    run(parser.parse_args())
