#!/usr/bin/env python3
import argparse, json, math, os, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import expit, gammaln, logsumexp
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree
from scipy.linalg import null_space, cho_factor, cho_solve
from scipy.optimize import minimize


def load_mesh_graph(mesh_csv):
    m = pd.read_csv(mesh_csv)
    key_to_idx = {}
    verts=[]; tris=[]
    for row in m.itertuples(index=False):
        tri=[]
        for x,y in [(row.x0,row.y0),(row.x1,row.y1),(row.x2,row.y2)]:
            key=(round(float(x),12),round(float(y),12))
            if key not in key_to_idx:
                key_to_idx[key]=len(verts); verts.append((float(x),float(y)))
            tri.append(key_to_idx[key])
        tris.append(tri)
    verts=np.asarray(verts,float); tris=np.asarray(tris,int)
    edges={}
    for a,b,c in tris:
        for u,v in [(a,b),(b,c),(c,a)]:
            if u>v: u,v=v,u
            dist=float(np.linalg.norm(verts[u]-verts[v]))
            edges[(u,v)]=min(edges.get((u,v),1e300),dist)
    rows=[]; cols=[]; vals=[]
    for (u,v),w in edges.items():
        rows.extend([u,v]); cols.extend([v,u]); vals.extend([w,w])
    G=csr_matrix((vals,(rows,cols)),shape=(len(verts),len(verts)))
    return verts,tris,G


def farthest_centers(G, verts, k, start_xy):
    start=int(np.argmin(np.sum((verts-np.asarray(start_xy))**2,axis=1)))
    centers=[start]
    min_dist=dijkstra(G,directed=False,indices=start)
    for _ in range(1,k):
        # deterministic farthest; avoid inf from disconnectedness
        finite=np.where(np.isfinite(min_dist),min_dist,-1)
        nxt=int(np.argmax(finite + 1e-12*np.arange(len(finite))))
        if nxt in centers: break
        centers.append(nxt)
        dn=dijkstra(G,directed=False,indices=nxt)
        min_dist=np.minimum(min_dist,dn)
    D=dijkstra(G,directed=False,indices=np.asarray(centers,int))
    return np.asarray(centers,int),np.asarray(D,float)


def soft_memberships(points, verts, D, topk=3, bandwidth_mult=1.0):
    # Approximate graph distance at a data point by graph distance at its nearest mesh vertex.
    nearest=cKDTree(verts).query(points,k=1)[1]
    dist=D[:,nearest].T  # n x centers
    kk=min(topk,dist.shape[1])
    idx=np.argpartition(dist,kk-1,axis=1)[:,:kk]
    dsel=np.take_along_axis(dist,idx,axis=1)
    # Local bandwidth uses kth center distance. This gives stable compact-ish memberships.
    h=np.maximum(dsel.max(axis=1)*bandwidth_mult,1e-6)
    w=np.exp(-0.5*(dsel/h[:,None])**2)
    w/=np.maximum(w.sum(axis=1,keepdims=True),1e-300)
    out=np.zeros_like(dist)
    np.put_along_axis(out,idx,w,axis=1)
    return out


def centered_cover_basis(M, train, weights):
    mass=np.sum(M[train]*weights[:,None],axis=0)
    mass/=mass.sum()
    U=null_space(mass.reshape(1,-1))
    B=M@U
    return B,U,mass


def standardize_columns(X, train, weights, eps=1e-10):
    sw=weights.sum()
    means=np.sum(X[train]*weights[:,None],axis=0)/sw
    X=X-means
    scales=np.sqrt(np.sum((X[train]**2)*weights[:,None],axis=0)/sw)
    keep=scales>eps
    X=X[:,keep]/scales[keep]
    return X,means,scales,keep


def make_design(MA,MB,train,weights,model):
    A,UA,mA=centered_cover_basis(MA,train,weights)
    B,UB,mB=centered_cover_basis(MB,train,weights)
    parts=[]; groups=[]; names=[]
    if model in ('parents','full'):
        parts += [A,B]
        groups += [np.zeros(A.shape[1],int),np.ones(B.shape[1],int)]
        names += ['A']*A.shape[1]+['B']*B.shape[1]
    if model in ('interaction','full'):
        Z=np.einsum('ij,ik->ijk',A,B,optimize=True).reshape(len(A),-1)
        parts.append(Z)
        g=0 if model=='interaction' else 2
        groups.append(np.full(Z.shape[1],g,int)); names += ['AB']*Z.shape[1]
    X=np.concatenate(parts,axis=1)
    groups=np.concatenate(groups)
    X,means,scales,keep=standardize_columns(X,train,weights)
    groups=groups[keep]
    names=np.asarray(names,object)[keep]
    return X.astype(np.float64),groups,names,dict(massA=mA,massB=mB)


def stratum_law(n,law):
    s=np.digitize(n,[128,512,4096])
    return s


def component_quadrature(k,n,eta,s2,xs,lw):
    uh=np.zeros_like(eta)
    for _ in range(35):
        p=expit(eta+uh)
        grad=n*p-k+uh/s2
        h=n*p*(1-p)+1/s2
        step=np.clip(grad/h,-2,2)
        new=np.clip(uh-step,-12,12)
        if np.max(np.abs(new-uh))<1e-8:
            uh=new; break
        uh=new
    p=expit(eta+uh)
    scale=1/np.sqrt(np.maximum(n*p*(1-p)+1/s2,1e-12))
    u=uh[None,:]+xs[:,None]*scale[None,:]
    q=expit(eta[None,:]+u)
    loglik=k[None,:]*np.log(np.clip(q,1e-14,1))+ (n-k)[None,:]*np.log1p(-np.clip(q,0,1-1e-14))
    T=lw[:,None]+0.5*xs[:,None]**2+loglik-0.5*u*u/s2
    logI=logsumexp(T,axis=0)+np.log(scale)-0.5*np.log(s2)
    ww=np.exp(T-logsumexp(T,axis=0)[None,:])
    score_node=k[None,:]-n[None,:]*q
    second_node=-n[None,:]*q*(1-q)
    score=np.sum(ww*score_node,axis=0)
    second=np.sum(ww*(second_node+score_node**2),axis=0)-score**2
    return logI,score,second


def marginal_stats(k,n,eta,law,xs,lw):
    logL=np.empty_like(eta); score=np.empty_like(eta); second=np.empty_like(eta)
    strata=stratum_law(n,law)
    for s in range(4):
        mask=strata==s
        if not np.any(mask): continue
        pi,s0,sL,_=law[s]
        lL,sL1,hL=component_quadrature(k[mask],n[mask],eta[mask],sL,xs,lw)
        l0,s01,h0=component_quadrature(k[mask],n[mask],eta[mask],s0,xs,lw)
        aa=np.log(pi)+lL; bb=np.log(1-pi)+l0
        den=logsumexp(np.vstack([aa,bb]),axis=0)
        wa=np.exp(aa-den); wb=1-wa
        sc=wa*sL1+wb*s01
        sec=wa*(hL+sL1*sL1)+wb*(h0+s01*s01)-sc*sc
        logL[mask]=den; score[mask]=sc; second[mask]=sec
    return logL,score,second


def fit_laplace_eb(X,groups,k,n,eta0,law,max_outer=8,verbose=False):
    xs,ws=np.polynomial.hermite_e.hermegauss(20); lw=np.log(ws/ws.sum())
    p=X.shape[1]; unique=np.unique(groups); ng=len(unique)
    beta=np.zeros(p)
    logtau=np.full(ng,-1.0)
    trace=[]
    for outer in range(max_outer):
        corr=X@beta; eta=eta0+corr
        logL,score,second=marginal_stats(k,n,eta,law,xs,lw)
        W=np.clip(-second,1e-4,5e5)
        z=corr+score/W
        # Dense normal equations; p is deliberately kept small.
        XW=X*W[:,None]
        H=X.T@XW
        r=X.T@(W*z)
        zWz=float(np.dot(W,z*z))
        counts=np.array([(groups==g).sum() for g in unique],float)
        def evidence_obj(lt,return_beta=False):
            tau=np.exp(lt); lamg=1/(tau*tau)
            lam=lamg[groups]
            A=H.copy(); A.flat[::p+1]+=lam
            try:
                cf=cho_factor(A,lower=True,check_finite=False)
                sol=cho_solve(cf,r,check_finite=False)
                logdetA=2*np.log(np.diag(cf[0])).sum()
            except Exception:
                return 1e100 if not return_beta else (1e100,None)
            logdetLam=np.sum(counts*np.log(lamg))
            # Weak regularization on log scales, only to avoid evidence-boundary pathologies.
            hyper=0.0
            val=0.5*np.dot(r,sol)+0.5*logdetLam-0.5*logdetA
            return (-val,sol) if return_beta else -val
        opt=minimize(evidence_obj,logtau,method='L-BFGS-B',bounds=[(-8.0,2.0)]*ng,
                     options={'maxiter':60,'ftol':1e-9})
        logtau=opt.x
        _,newbeta=evidence_obj(logtau,True)
        # Damped update chosen on penalized true objective.
        lam=1/(np.exp(logtau[groups])**2)
        def post(b):
            ll=marginal_stats(k,n,eta0+X@b,law,xs,lw)[0].sum()
            return ll-0.5*np.dot(lam,b*b)
        oldpost=post(beta)
        step=1.0
        while step>1/64:
            trial=beta+step*(newbeta-beta)
            val=post(trial)
            if val>=oldpost-1e-7: break
            step*=0.5
        delta=float(np.max(np.abs(trial-beta)))
        beta=trial
        tr=dict(outer=outer,post=val,step=step,max_delta=delta,
                tau=np.exp(logtau).tolist(),mean_W=float(W.mean()),min_W=float(W.min()))
        trace.append(tr)
        if verbose: print('[fit]',tr,flush=True)
        if delta<2e-4: break
    return beta,np.exp(logtau),trace


def evaluate_nll(k,n,eta,mask,law):
    xs,ws=np.polynomial.hermite_e.hermegauss(20); lw=np.log(ws/ws.sum())
    logL=marginal_stats(k[mask],n[mask],eta[mask],law,xs,lw)[0]
    const=gammaln(n[mask]+1)-gammaln(k[mask]+1)-gammaln(n[mask]-k[mask]+1)
    return float(np.mean(-(logL+const)))


def run(args):
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    raw=pd.read_csv(args.data)
    obs=pd.read_csv(args.obs).sort_values('pid').reset_index(drop=True)
    n=raw.n0.to_numpy(float); k=raw.k_term.to_numpy(float)
    eta0=np.log(np.clip(obs.p_hat.to_numpy(float),1e-12,1-1e-12)/np.clip(1-obs.p_hat.to_numpy(float),1e-12,1))
    train=obs.is_train.to_numpy(int)==1; held=~train
    points=np.column_stack([raw.wala.to_numpy(float)/360.0,(raw.wac.to_numpy(float)-2.6)/5.0])
    verts,tris,G=load_mesh_graph(args.mesh)
    sa=tuple(float(x) for x in args.start_a.split(',')); sb=tuple(float(x) for x in args.start_b.split(','))
    ca,Da=farthest_centers(G,verts,args.centers,sa)
    cb,Db=farthest_centers(G,verts,args.centers,sb)
    MA=soft_memberships(points,verts,Da,args.topk,args.bandwidth)
    MB=soft_memberships(points,verts,Db,args.topk,args.bandwidth)
    base_weight=np.maximum(obs['info'].to_numpy(float)[train],1e-5)
    law=json.load(open(args.law))['law']
    rows=[]
    for model in args.models.split(','):
        model=model.strip()
        X,groups,names,meta=make_design(MA,MB,train,base_weight,model)
        beta,tau,trace=fit_laplace_eb(X[train],groups,k[train],n[train],eta0[train],law,args.outer,args.verbose)
        corr=X@beta; eta=eta0+corr
        masks={
          'all':held,
          'ramp':held&(raw.wala.to_numpy()<24)&(raw.wac.to_numpy()>=5.5)&(raw.wac.to_numpy()<7),
          'mid':held&(raw.wala.to_numpy()>=60)&(raw.wala.to_numpy()<200),
          'seasoned':held&(raw.wala.to_numpy()>=200)&(raw.wala.to_numpy()<300)&(raw.wac.to_numpy()>=5.5)&(raw.wac.to_numpy()<7),
        }
        metrics={f'nll_{name}':evaluate_nll(k,n,eta,mask,law) for name,mask in masks.items()}
        train_nll=evaluate_nll(k,n,eta,train,law)
        row=dict(model=model,centers=args.centers,topk=args.topk,bandwidth=args.bandwidth,
                 parameters=len(beta),train_nll=train_nll,taus=';'.join(f'{x:.8g}' for x in tau),
                 correction_rms=float(np.sqrt(np.mean(corr[held]**2))),
                 correction_max=float(np.max(np.abs(corr[held]))),**metrics)
        rows.append(row)
        od=out/model; od.mkdir(exist_ok=True)
        outobs=obs.copy(); outobs['p_hat']=expit(eta); outobs['crossed_correction']=corr
        outobs.to_csv(od/'run_obs.csv',index=False)
        pd.DataFrame({'coefficient':np.arange(len(beta)),'group':groups,'name':names,'beta':beta}).to_csv(od/'coefficients.csv',index=False)
        json.dump({'tau':tau.tolist(),'trace':trace,'centersA':ca.tolist(),'centersB':cb.tolist()},open(od/'fit.json','w'),indent=2)
        print('[result]',row,flush=True)
    pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--obs',required=True); ap.add_argument('--mesh',required=True); ap.add_argument('--data',required=True); ap.add_argument('--law',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--centers',type=int,default=12); ap.add_argument('--topk',type=int,default=3); ap.add_argument('--bandwidth',type=float,default=1.0)
    ap.add_argument('--start-a',default='0,0'); ap.add_argument('--start-b',default='0.5,0.5')
    ap.add_argument('--models',default='parents,interaction,full'); ap.add_argument('--outer',type=int,default=7); ap.add_argument('--verbose',action='store_true')
    run(ap.parse_args())
